tr_ <- function(...) {
  enc2utf8(gettext(paste0(...), domain = "R-sandpaper"))
}
