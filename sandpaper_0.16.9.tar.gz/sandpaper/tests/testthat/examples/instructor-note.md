::: instructor

### This *is* a note

```bash
echo with code
```

:::


This is not part of the note
