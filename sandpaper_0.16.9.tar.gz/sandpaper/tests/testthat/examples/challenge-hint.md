::: challenge

### A new challenger approaches!

How do you prepare?

::: hint

A bard can help

:::

::: solution

USE THE BARD

:::
:::
