#' The varnish package 
#'
#' This package does not contain any useful R code. It serves to hold CSS, JS,
#' and HTML styling for Carpentries lessons. 
#' @keywords internal
"_PACKAGE"

## usethis namespace: start
## usethis namespace: end
NULL
