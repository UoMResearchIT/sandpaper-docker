::: challenge

### A new challenger approaches!

How do you prepare?

::: hint

A bard can help

:::

::: solution

USE THE BARD

:::

### How were you wise?

Did you use the resources available to you? Did you lean on your traits?

:::
