library(testthat)
library(sandpaper)

test_check("sandpaper")
