## ---- include = FALSE, message = FALSE----------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#|"
)

## ----setup--------------------------------------------------------------------
library("sandpaper")

## ----use_package_cache, eval = FALSE------------------------------------------
#  use_package_cache()

## ----output, echo = FALSE-----------------------------------------------------
msg <- readLines(system.file("resources/WELCOME", package = "renv"))
msg <- gsub("${RENV_PATHS_ROOT}", dQuote("/path/to/cache"), msg, fixed = TRUE)
choices <- sandpaper:::message_package_cache(msg)
cat(paste(c("1:", "2:"), choices), sep = "\n")

## ----build-lesson-dummy, eval = FALSE-----------------------------------------
#  build_lesson()

## ----build-lesson-dummy2, eval = FALSE----------------------------------------
#  no_package_cache()
#  sandpaper:::build_markdown(rebuild = TRUE)

## ---- eval = FALSE------------------------------------------------------------
#  use_package_cache()

## ---- eval = FALSE------------------------------------------------------------
#  package_cache_trigger()
#  #| [1] FALSE
#  package_cache_trigger(TRUE) # set the package cache to auto-trigger rebuilds
#  #| [1] TRUE
#  package_cache_trigger(FALSE) # prevent package cache from triggering rebuilds
#  #| [1] FALSE

## ----eval = FALSE-------------------------------------------------------------
#  pin_version("cowsay@0.7.0")

## ----update-cache, eval = FALSE-----------------------------------------------
#  update_cache(prompt = TRUE)

