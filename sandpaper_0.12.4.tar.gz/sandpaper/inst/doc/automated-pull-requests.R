## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#|"
)

## ----eval = FALSE-------------------------------------------------------------
#  update_github_workflows()  # updates the package workflows
#  update_cache()      # uses `renv::update()` to check for updates to the package cache

