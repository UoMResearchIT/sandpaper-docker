#' @keywords internal
"_PACKAGE"

# The following block is used by usethis to automatically manage
# roxygen namespace tags. Modify with care!
## usethis namespace: start
#' @importFrom utils read.table
#' @importFrom utils write.table
#' @importFrom utils modifyList
#' @importFrom utils tail
#' @importFrom tools md5sum
#' @importFrom tools file_ext
#' @importFrom rlang is_interactive
## usethis namespace: end
NULL
